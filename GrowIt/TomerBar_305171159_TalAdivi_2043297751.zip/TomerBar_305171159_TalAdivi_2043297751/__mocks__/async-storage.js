export default from '@react-native-communityasync-storagejestasync-storage-mock';

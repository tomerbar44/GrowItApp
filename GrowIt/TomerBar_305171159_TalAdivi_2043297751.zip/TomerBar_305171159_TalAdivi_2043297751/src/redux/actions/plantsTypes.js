export const SET_PLANTS_LIST = 'SET_PLANTS_LIST';
export const SET_MY_PLANTS_LIST = 'SET_MY_PLANTS_LIST';
export const ADD_PLANT_TO_LIST = 'ADD_PLANT_TO_LIST';
export const INIT_SYS = 'INIT_SYS';

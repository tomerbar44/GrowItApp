import { combineReducers } from 'redux';
import plantsReducer from './reducers/plantsReducer';

export default combineReducers({
  plantsReducer
});
